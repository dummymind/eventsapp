import React from 'react';

function ListItems() {
    return (
        <div className="listitems">
            {/* Your list items content goes here */}
        </div>
    );
}

export default ListItems;
