export const variables = {
    API_URL: "http://localhost:44311/api/"
}