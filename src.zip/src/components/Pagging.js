import React from 'react';
 
function Pagging() {
    return (
        <div className="paging align-items-center">
            <span className="centered-text">1-1 OF 1 ELEMENTS</span>
        </div>
    );
}
 
export default Pagging;
 