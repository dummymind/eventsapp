import React from 'react';

export default function Main() {
    return (
      <div className="container-fluid">
        <div className="progress d-flex flex-column" style={{ backgroundColor: 'gainsboro', height: '100%' }}>
          <div className="row">
            <div className="col-md-7">
            </div>
            <div className="col-md-4">
            </div>
          </div>
        </div>
      </div>
    );
}